import 'package:flutter/material.dart';

class KoldonmoColors {
  static const Color bgColor = Colors.amber;
}
