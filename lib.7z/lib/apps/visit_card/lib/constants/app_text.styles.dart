import 'package:flutter/material.dart';

class KoldonmoTextStyles {
  static const TextStyle textStyle = TextStyle(
    fontFamily: "Pacifico",
    color: Colors.black,
    fontSize: 48.0,
  );
}
