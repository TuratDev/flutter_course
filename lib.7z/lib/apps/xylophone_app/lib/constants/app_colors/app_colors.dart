import 'package:flutter/material.dart';

class AppColors {
  static const Color red = Colors.red;
  static const Color orange = Colors.orange;
  static const Color yellow = Colors.yellow;
  static const Color green = Colors.green;
  static const Color teal = Colors.teal;
  static const Color blue = Colors.blue;
  static const Color purple = Colors.purple;
}
