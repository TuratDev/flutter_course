import 'package:flutter/material.dart';

// БУЛ ЖЕРГЕ ӨЗҮҢДҮН ФАЙЛДАРЫҢДЫ ИМПОРТТО (Мисалы)
// import 'package:flutter_portfolio/apps/bmi_calculator/lib/main.dart';
// Эскертүү: Класстардын аттары бирдей болсо (мисалы, баарында MyApp болсо),
// аларды 'as BmiApp' деп ат коюп алсаң болот.

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Бардык тапшырмалар!'),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionTitle('Башталгыч деңгээл'),
          // 1. Counter App
          _buildAppItem(
            context,
            'Counter App',
            Icons.add_circle_outline,
            Colors.teal,
            destination: null,
          ), // Бул жерге CounterApp'тын классын жаз
          // 2. I'm Rich
          _buildAppItem(
            context,
            "I'm Rich",
            Icons.diamond,
            Colors.amber,
            destination: null,
          ), // Бул жерге ImRich классын жаз
          // 3. Visit Card
          _buildAppItem(
            context,
            'Visit Card',
            Icons.contact_mail,
            Colors.blueGrey,
            destination: null,
          ), // Бул жерге VisitCard классын жаз

          const SizedBox(height: 20),
          _buildSectionTitle('Орто деңгээл'),
          // 4. Dice App
          _buildAppItem(
            context,
            'Dice App',
            Icons.casino,
            Colors.redAccent,
            destination: null,
          ),

          // 5. Quiz App
          _buildAppItem(
            context,
            'Quiz App',
            Icons.check_circle_outline,
            Colors.green,
            destination: null,
          ),

          const SizedBox(height: 20),
          _buildSectionTitle('Логика'),
          // 6. BMI Calculator
          _buildAppItem(
            context,
            'BMI Calculator',
            Icons.monitor_weight,
            Colors.indigo,
            destination: null,
          ),

          const SizedBox(height: 20),
          _buildSectionTitle('Кийинки кошула тургандар'),
          _buildAppItem(
            context,
            'Xylophone App',
            Icons.music_note,
            Colors.purple,
          ),
          _buildAppItem(
            context,
            'The Weather App',
            Icons.wb_sunny,
            Colors.orange,
          ),
          _buildAppItem(context, 'Test Country', Icons.public, Colors.cyan),
          _buildAppItem(
            context,
            'Flash Chat App',
            Icons.bolt,
            Colors.yellow[800]!,
          ),
          _buildAppItem(context, 'The News App', Icons.newspaper, Colors.brown),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 8, bottom: 8),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: Colors.grey,
        ),
      ),
    );
  }

  Widget _buildAppItem(
    BuildContext context,
    String title,
    IconData icon,
    Color color, {
    Widget? destination,
  }) {
    return Card(
      elevation: 1,
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          if (destination != null) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => destination),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('$title азырынча кошула элек (иштеп жатабыз)'),
              ),
            );
          }
        },
      ),
    );
  }
}
